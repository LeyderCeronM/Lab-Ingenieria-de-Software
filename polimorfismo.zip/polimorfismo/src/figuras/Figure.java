
package figuras;


public abstract  class Figure {
        
   // Metodo utilizados en cada figura a trabajar 
   public abstract double  calcularArea();  
   public abstract double  calcularPerimetro();
   public abstract String   getNombre();

}
